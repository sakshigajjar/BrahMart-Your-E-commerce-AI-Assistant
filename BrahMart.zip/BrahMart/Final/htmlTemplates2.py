new = '''
<style>
h1#ai4researchers{
    font-family: 'Montserrat';
    font-size:72px;
    color: #0a5c52;
  }
}
</style>
<style>
h3#hello-this-is-your-research-assitant{
    padding: 0px;
}</style>
<style>
[data-testid="stFileUploadDropzone"]{
background: rgb(10,92,82);
background: linear-gradient(90deg, rgba(10,92,82,1) 0%, rgba(2,160,149,1) 100%);
color: #fff;
}
</style>
<style>
section.main.css-uf99v8.e1g8pov65
{
    
}
</style>
<style>
[data-testid="main-menu-list"]{
    color: fc4c4c;
}
</style>
<style>
p{
    font-size:16px;
    font-color: #fff;
}
</style>
<style>
.stApp {
  background-image: url("data:image/png;base64,%s");
  background-size: cover;
}
</style>
<style>
div.css-k3w14i effi0qh3{
    font-size:24px;
}
</style>
<style>
span.css-10trblm.eqr7zpz0{
    font:Montserrat;
}
</style>

<style>
.chat-message {
    padding: 1.5rem; border-radius: 0.5rem; margin-bottom: 1rem; display: flex
}
.chat-message.user {
    background-color: #E0DADA
}
.chat-message.bot {
    background-color: #C7BFBF
}
.chat-message .avatar {
  width: 20%;
}
.chat-message .avatar img {
  max-width: 78px;
  max-height: 78px;
  border-radius: 50%;
  object-fit: cover;
}
.chat-message .message {
  width: 80%;
  padding: 0 1.5rem;
  color: #fff;
}
'''

bot_template = '''
<div class="chat-message bot">
    
    <div class="message">{{MSG}}</div>
</div>
'''

user_template = '''
<div class="chat-message user">
    
    <div class="message">{{MSG}}</div>
    
</div>
'''
background_image = """
<style>
body {
    [data-testid="stAppViewContainer"]
    background-image: url('1.jpg');
    background-size: cover;
    
    }
</style>
"""
page_bg_img = '''
<style>
section.main.css-uf99v8. e1g8pov65{
background-image: url("https://images.unsplash.com/photo-1542281286-9e0a16bb7366");
background-size: cover;
}
</style>
'''

