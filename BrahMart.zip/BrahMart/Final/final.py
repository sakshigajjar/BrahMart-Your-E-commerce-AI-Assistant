import streamlit as st
from streamlit_mic_recorder import mic_recorder, speech_to_text
from streamlit_chat import message
import numpy as np
import pyttsx3
from dotenv import load_dotenv
from htmlTemplates2 import new, bot_template, user_template, background_image
import time
from langchain.prompts import ChatPromptTemplate
from langchain.prompts import SystemMessagePromptTemplate
from langchain.prompts import HumanMessagePromptTemplate
from langchain_core.messages import HumanMessage
from langchain_community.document_loaders import JSONLoader
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
import json
from langchain_text_splitters import RecursiveJsonSplitter
from langchain.vectorstores import FAISS
import os
import getpass
from langchain.chat_models import ChatOpenAI
from langchain.text_splitter import CharacterTextSplitter
from langchain_core.prompts import PromptTemplate
from langchain.embeddings import OpenAIEmbeddings
from langchain_community import OpenAIEmbeddings
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain,LLMChain
from langchain.docstore.document import Document
import time
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
import openai
from langchain.chains import ConversationalRetrievalChain
from langchain_community.vectorstores import FAISS